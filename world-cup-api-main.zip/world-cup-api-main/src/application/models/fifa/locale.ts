export default interface Localized {
  Locale: string;
  Description: string;
}
