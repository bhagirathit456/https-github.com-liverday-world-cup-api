type EventResponse = {
  typeOfEvent: string;
  player: string;
  extraInfo: any;
  minute: string;
};

export default EventResponse;
