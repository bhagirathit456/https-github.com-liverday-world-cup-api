# World Cup 2022 API

Currently we have the following endpoints available:

- [/teams/:country](https://copa22.medeiro.tech/teams/bra)
- [/teams/:country/matches](https://copa22.medeiro.tech/teams/bra/matches)
- [/groups](https://copa22.medeiro.tech/groups)
- [/brackets](https://copa22.medeiro.tech/brackets)
- [/matches](https://copa22.medeiro.tech/matches)
- [/matches/today](https://copa22.medeiro.tech/matches/today)
- [/matches/current](https://copa22.medeiro.tech/matches/current)
- [/matches/:id](https://copa22.medeiro.tech/matches/clakj8jii002lra2tbbzc3264)