# alpha-0.0.1

- DEPRECATION NOTICE: Deprecating "substitutions" property on `homeTeam`, `awayTeam` on `/matches/current` and `/matches/:id` endpoint. You should use `events` instead. On the next versions this property will be removed.
- Add timeline events on `/matches/current` and `/matches/:id`